class Calculator:
    def __init__(self):
        pass

    def add(self, x, y):
        return x + y

    def subtract(self, x, y):
        return x - y

    def multiply(self, x, y):
        return x * y

    def divide(self, x, y):
        if y == 0:
            return "Cannot divide by zero"
        return x / y

if __name__ == "__main__":
    calc = Calculator()

    while True:
        print("Options:")
        print("1. Add")
        print("2. Subtract")
        print("3. Multiply")
        print("4. Divide")
        print("5. Exit")
        choice = input("Enter choice (1/2/3/4/5): ")

        if choice == '5':
            print("Calculator shutting down.")
            break

        num1 = float(input("Enter first number: "))
        num2 = float(input("Enter second number: "))

        if choice == '1':
            print("Results:", calc.add(num1, num2))
            print("_________________________________")

        elif choice == '2':
            print("Results:", calc.subtract(num1, num2))
            print("_________________________________")

        elif choice == '3':
            print("Results:", calc.multiply(num1, num2))
            print("_________________________________")

        elif choice == '4':
            print("Results:", calc.divide(num1, num2))
            print("_________________________________")

        else:
            print("Invalid choice. Please enter a valid option.")
